#import <Flutter/Flutter.h>

@interface JustAudioPlugin : NSObject<FlutterPlugin>
@end
